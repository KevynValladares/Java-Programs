/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package something.gotchi;

import java.awt.*;
import javax.swing.JFrame;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 *
 * @author 136-kvalladares
 */
public class SomethingGotchiTester extends Canvas {

    public static int x1 = 100;
    public static int y1 = 200;
    public static int x2 = 1025;
    public static int y2 = 200;

    /**
     * @param args the command line arguments
     */
    public void paint(Graphics g) {
        int sC = 400;
        int s2C = 400;
        Image somethingGotchi2 = null;
        Image somethingGotchi1 = null;
        Image black = null;
        try {
            black = ImageIO.read(new File("black.jpg"));
        } catch (IOException ex) {
            Logger.getLogger(SomethingGotchiTester.class.getName()).log(Level.SEVERE, null, ex);
        }
        Image b = black.getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        Image bText = black.getScaledInstance(100, 25, Image.SCALE_DEFAULT);
        try {
            somethingGotchi2 = ImageIO.read(new File("SomethingGotchiImage.png"));
        } catch (IOException ex) {
            Logger.getLogger(SomethingGotchiTester.class.getName()).log(Level.SEVERE, null, ex);
        }
        Image newImage = somethingGotchi2.getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        try {
            somethingGotchi1 = ImageIO.read(new File("SomethingGotchiImage2.png"));
        } catch (IOException ex) {
            Logger.getLogger(SomethingGotchiTester.class.getName()).log(Level.SEVERE, null, ex);
        }
        Image newImage2 = somethingGotchi1.getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        int userInput = 1;
        Scanner input = new Scanner(System.in);
        String p1 = "Player1";
        String p2 = "Player2";
        System.out.println("Welcome to the something-gotchi game");
        System.out.println("You can choose your own attack power,");
        System.out.println("but if it's 10 and below, you can get a critical hit!");
        System.out.println("If it's 5 and below, your get a super critical hit!");
        System.out.println("If your attack power is more than 20, I will just round it down!");
        System.out.println("Enter the attack power for player 1: ");
        userInput = input.nextInt();
        if (userInput > 20) {
            userInput = 20;
        }
        SomethingGotchi s = new SomethingGotchi(userInput);
        System.out.println("Enter the attack power for player 2: ");
        userInput = input.nextInt();
        if (userInput > 20) {
            userInput = 20;
        }
        SomethingGotchi s2 = new SomethingGotchi(userInput);
        s.setLocation(100, 250);
        s.setLocation(500, 250);
        g.setColor(Color.red);
        g.drawString(p1, 100, 100);
        g.drawString(p2, 1025, 100);
        g.drawString("Health: " + s.health, 100, 125);
        g.drawString("AttackPower: " + s.attackPower, 100, 150);
        g.drawString("Health: " + s2.health, 1025, 125);
        g.drawString("AttackPower: " + s2.attackPower, 1025, 150);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(SomethingGotchiTester.class.getName()).log(Level.SEVERE, null, ex);
        }
        g.drawString("Battle!", 640, 50);
        g.drawImage(newImage, x2, y2, this);
        g.drawImage(newImage2, x1, y1, this);
        while (s.health > 0 && s2.health > 0) {
            /*System.out.println("Enter the attack power for player 1: ");
            s.attackPower = input.nextInt();
            if (s.attackPower > 20) {
                s.attackPower = 20;
            }
            System.out.println("Enter the attack power for player 2: ");
            s2.attackPower = input.nextInt();
            if (s2.attackPower > 20) {
                s2.attackPower = 20;
            }
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ex) {
                Logger.getLogger(SomethingGotchiTester.class.getName()).log(Level.SEVERE, null, ex);
            }*/
            for (int i = 1; i <= 415; i++) {
                x1 = moveForward(x1);
                g.drawImage(newImage2, x1, y1, this);
                x2 = moveBackward(x2);
                g.drawImage(newImage, x2, y2, this);
            }
            s.health = s.takeDamage(s2.attackPower);
            s2.health = s2.takeDamage(s.attackPower);
            if (s2.isCritical == true) {
                g.setColor(Color.cyan);
                g.drawString("Critical!!!", 500, s2C);
                s2C += 50;
            } else if (s2.isSuperCritical == true) {
                g.setColor(Color.magenta);
                g.drawString("SUPER CRITICAL!!!", 500, s2C);
                s2C += 50;
            } if (s.isCritical == true) {
                g.setColor(Color.cyan);
                g.drawString("Critical!!!", 700, sC);
                sC += 50;
            } else if (s.isSuperCritical == true) {
                g.setColor(Color.magenta);
                g.drawString("SUPER CRITICAL!!!", 700, sC);
                sC += 50;
            }

            g.drawImage(bText, 1025, 100, this);
            g.drawImage(bText, 100, 100, this);
            g.drawImage(bText, 1025, 125, this);
            g.drawImage(bText, 100, 125, this);

            g.drawString("Health: " + s2.health, 1025, 125);
            g.drawString("Health: " + s.health, 100, 125);

            g.drawString("AttackPower: " + s.attackPower, 100, 150);
            g.drawString("AttackPower: " + s2.attackPower, 1025, 150);

            for (int i = 1; i <= 415; i++) {
                g.drawImage(b, x1, y1, this);
                x1 = moveBackward(x1);
                g.drawImage(newImage2, x1, y1, this);
                g.drawImage(b, x2, y2, this);
                x2 = moveForward(x2);
                g.drawImage(newImage, x2, y2, this);
                try {
                    Thread.sleep(2);
                } catch (InterruptedException ex) {
                    Logger.getLogger(SomethingGotchiTester.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (s2.isDefeated == true && s.isDefeated == true) {
                g.drawImage(b, 640, 50, this);
                g.drawString("It's a draw!", 640, 100);
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(SomethingGotchiTester.class.getName()).log(Level.SEVERE, null, ex);
                }
                System.exit(0);
            } else if (s2.isDefeated == true) {
                g.drawImage(b, x2, y2, this);
                g.drawImage(b, 640, 50, this);
                g.drawString("Player 1 Wins!", 640, 100);
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(SomethingGotchiTester.class.getName()).log(Level.SEVERE, null, ex);
                }
                System.exit(0);
            } else if (s.isDefeated == true) {
                g.drawImage(b, x1, y1, this);
                g.drawImage(b, 640, 100, this);
                g.drawString("Player 2 Wins!", 640, 100);
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(SomethingGotchiTester.class.getName()).log(Level.SEVERE, null, ex);
                }
                System.exit(0);
            }
        }
    }

    public int moveForward(int xPosition) {
        xPosition++;
        return (xPosition);
    }

    public int moveBackward(int xPosition) {
        xPosition--;
        return (xPosition);
    }

    public static void main(String[] args) {
        JFrame win = new JFrame("BattleArena");
        win.setSize(1280, 720);
        win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        win.getContentPane().setBackground(Color.black);
        SomethingGotchiTester canvas = new SomethingGotchiTester();
        win.add(canvas);
        win.setVisible(true);
    }
}
