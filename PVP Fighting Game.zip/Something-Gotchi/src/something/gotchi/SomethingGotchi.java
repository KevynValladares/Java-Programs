/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package something.gotchi;

import java.util.Random;

/**
 *
 * @author 136-kvalladares
 */
public class SomethingGotchi {

    int health;
    int attackPower;
    boolean isDefeated;
    int x;
    int y;
    int damage;
    boolean isCritical;
    boolean isSuperCritical;

    public SomethingGotchi(int newAttackPower) {
        attackPower = newAttackPower;
        isDefeated = false;
        health = 100;
        isCritical = false;
        isSuperCritical = false;
    }

    public int takeDamage(int newAttackPower) {
        int random = 1;
        if (newAttackPower > 10) {
            random = 1;
        } else if (newAttackPower < 11) {
            random = 2;
        }
        Random r = new Random();
        int chance = r.nextInt(random - 1 + 1) + 1;
        damage = r.nextInt(newAttackPower - 1 + 1) + 1;
        if (chance > 1) {
            if (newAttackPower < 6) {
                damage *= 5;
                isSuperCritical = true;
            } else if (newAttackPower < 11) {
                damage *= 2;
                isCritical = true;
            }
        } if(chance == 1) {
            isCritical = false;
            isSuperCritical = false;
        }

        health -= damage;
        if (health <= 0) {
            health = 0;
            isDefeated = true;
        }
        return (health);
    }

    public void setLocation(int newX, int newY) {
        x = newX;
        y = newY;
    }

    public int getHealth() {
        return (health);
    }
}
