/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author 136-kvalladares
 */
public class MastermindTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        Random r = new Random();
        int[] userInput = new int[5];
        int[] code = new int[5];
        int corrections = 0, presence = 0;
        int[] checking = new int[5];
        int[] taboo = new int[5];
        System.out.println("Welcome to the MasterMind game!");
        System.out.println("Try to guess the 4 digit code!");
        System.out.println("(Enter 1 digit per line)");
        for (int i = 1; i < code.length; i++) {
            code[i] = r.nextInt(8 - 1 + 1) + 1;
            taboo[i] = 0;
            checking[i] = code[i];
            System.out.print(code[i] + " ");
        }
        System.out.println("");
        for (int i = 1; i < 11; i++) {
            System.out.println("\nGuess " + i);
            for (int j = 1; j < code.length; j++) {
                userInput[j] = input.nextInt();
                checking[j] = code[j];
            }

            /*for (int j = 1; j < code.length; j++) {
                System.out.print(checking[j] + " ");
            }*/
            for (int j = 1; j < code.length; j++) {
                System.out.print(userInput[j] + " ");
                if (checking[j] == userInput[j]) {
                    corrections++;
                    userInput[j] = 0;
                    checking[j] = 11;
                }
            }
            System.out.println("");
            for (int j = 1; j < 5; j++) {
                for (int k = 1; k < 5; k++) {
                    /*if (checking[k] == userInput[k]) {
                        userInput[k] = 0;
                        checking[k] = 11;
                    }*/
                    if (k != j) {
                        if (checking[k] == userInput[j]) {
                            presence++;
                            userInput[j] = 0;
                            checking[k] = 11;
                        }
                    }
                    for (int l = 1; l < code.length; l++) {
                        //System.out.print(checking[l] + " ");
                    }
                    //System.out.println("");
                    for (int l = 1; l < code.length; l++) {
                        //System.out.print(userInput[l] + ", ");
                    }
                }
                //System.out.println("");
            }
            System.out.println("");
            if (corrections != 4) {
                System.out.println(corrections + " correct, " + presence + " not quite, " + (4 - (corrections + presence)) + " wrong");
            } else {
                System.out.println("You cracked the code!");
                System.out.print("It was ");
                for (int j = 1; j < code.length; j++) {
                    System.out.print(code[j] + " ");
                }
                System.out.println("");
                System.exit(0);
            }
            corrections = 0;
            presence = 0;
        }
        System.out.println("You failed!");
        System.out.print("The code was ");
        for (int j = 1; j < code.length; j++) {
            System.out.print(code[j] + " ");
        }
    }
}
