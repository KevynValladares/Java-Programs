/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package passwordtester;

import java.util.Scanner;

/**
 *
 * @author 136-kvalladares
 */
public class PasswordTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String password;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter your password: ");
        password = input.next();
        boolean isLong = false, hasCaps = false, hasLower = false, hasNum = false, hasSymbol = false, isStrong = false;
        String specialChars = "/*!@#$%^&*()\"{}_[]|\\?/<>,.";
        int passwordLength = password.length();
        isLong = passwordLength <= 16 && passwordLength >= 12;
        System.out.println("Is long enough: " + isLong);
        System.out.println("Length: " + passwordLength);
        for (int i = 0; i < password.length(); i++) {
            if (hasCaps == false) {
                hasCaps = Character.isUpperCase(password.charAt(i));
            }
            if (hasLower == false) {
                hasLower = Character.isLowerCase(password.charAt(i));
            }
            if (hasNum == false) {
                hasNum = Character.isDigit(password.charAt(i));
            }
            if (hasSymbol == false) {
                for (int j = 0; j < specialChars.length(); j++) {
                    if (hasSymbol == false) {
                        hasSymbol = password.charAt(i) == specialChars.charAt(j);
                    }
                }
            }
        }
        System.out.println("HasCaps: " + hasCaps);
        System.out.println("HasLower: " + hasLower);
        System.out.println("HasNum: " + hasNum);
        System.out.println("HasSymbol: " + hasSymbol);
        isStrong = isLong && hasCaps && hasLower && hasNum && hasSymbol;
        if (isStrong) {
            System.out.println("Your password is strong");
        }
        else{
            System.out.println("Your password is not strong enough");
        }
    }
}
